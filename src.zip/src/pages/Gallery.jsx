const Gallery = () => {
  const images = [
    "https://images.unsplash.com/photo-1501004318641-b39e6451bec6",
    "https://images.unsplash.com/photo-1495395226200-8fbf6b97a79d",
    "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
  ];

  return (
    <section className="max-w-5xl mx-auto text-center">
      <h1 className="text-3xl font-bold text-green-800 mb-6">
        Our Green Memories 🌿
      </h1>
      <div className="grid md:grid-cols-3 gap-4">
        {images.map((img, i) => (
          <img
            key={i}
            src={img}
            alt="Plantation"
            className="rounded-lg shadow-lg hover:scale-105 transition"
          />
        ))}
      </div>
    </section>
  );
};

export default Gallery;
