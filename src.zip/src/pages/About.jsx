import React from "react";

export default function About() {
  return (
    <div className="bg-green-50 text-gray-800">
      {/* Header Section */}
      <section className="bg-green-800 text-white text-center py-16">
        <h1 className="text-4xl md:text-5xl font-bold">
          वृक्ष मित्र संस्था के बारे में 🌳
        </h1>
        <p className="mt-4 text-lg text-green-100 max-w-3xl mx-auto">
          हम एक पर्यावरण संरक्षण संगठन हैं जो पेड़ लगाने, उनकी देखभाल करने और
          लोगों को प्रकृति के प्रति संवेदनशील बनाने का कार्य करता है।
        </p>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <img
            src="https://cdn.pixabay.com/photo/2016/11/29/06/17/earth-1866533_1280.png"
            alt="Mission"
            className="rounded-xl w-full md:w-10/12 mx-auto shadow-md"
          />
          <div>
            <h2 className="text-3xl font-bold text-green-800 mb-4">
              हमारा मिशन 🌏
            </h2>
            <p className="text-gray-700 leading-relaxed">
              हमारा मिशन धरती को हरियाली से भरना, वायु को स्वच्छ बनाना और जलवायु
              परिवर्तन से निपटना है। वृक्ष मित्र संस्था का मानना है कि हर
              व्यक्ति एक पौधे के माध्यम से भविष्य को हरा बना सकता है।
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-10 items-center mt-20">
          <div>
            <h2 className="text-3xl font-bold text-green-800 mb-4">
              हमारी दृष्टि 🌿
            </h2>
            <p className="text-gray-700 leading-relaxed">
              एक ऐसा समाज जहाँ हर व्यक्ति पर्यावरण के प्रति जिम्मेदार हो। हम आने
              वाले वर्षों में लाखों पेड़ लगाने, जल संरक्षण और प्रदूषण नियंत्रण
              के प्रति जागरूकता फैलाने का लक्ष्य रखते हैं।
            </p>
          </div>
          <img
            src="https://cdn.pixabay.com/photo/2017/06/20/20/00/trees-2422097_1280.jpg"
            alt="Vision"
            className="rounded-xl w-full md:w-10/12 mx-auto shadow-md"
          />
        </div>
      </section>

      {/* Founder Section */}
      <section className="bg-white py-16 border-t border-green-200">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-10 items-center">
          <img
            src="/yogendra-sir.jpg"
            alt="Shree Yogendra Sir"
            className="rounded-2xl w-80 mx-auto shadow-lg border-4 border-green-300"
          />
          <div>
            <h2 className="text-3xl font-bold text-green-800 mb-3">
              संस्थापक: श्री योगेन्द्र सर 🙏
            </h2>
            <p className="text-gray-700 leading-relaxed text-lg">
              वृक्ष मित्र संस्था के संस्थापक{" "}
              <span className="font-semibold text-green-700">
                श्री योगेन्द्र सर
              </span>{" "}
              के ही मार्गदर्शन में सभी वृक्ष मित्र मिलकर इस अभियान को
              सफलतापूर्वक संचालित कर रहे हैं। उनका उद्देश्य है — “हर व्यक्ति एक
              वृक्ष लगाए, और धरती को फिर से हरा-भरा बनाए।” 🌱
            </p>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="bg-white py-16">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-green-800 mb-10">
            हमारी यात्रा 🕊️
          </h2>

          <div className="relative border-l-4 border-green-600">
            {[
              {
                year: "2019",
                title: "पहला पौधारोपण 🌱",
                desc: "वृक्ष मित्र संस्था का प्रथम पौधारोपण पी एम श्री शासकीय नवीन माध्यमिक शाला खैरुआ में कल्पतरु अभियान के सदस्यों के द्वारा 20 जनवरी 2019 को किया गया। तब से हर सप्ताह पौधारोपण जारी है और संस्था अब तक 351वें सप्ताह में प्रवेश कर चुकी है।",
              },
              {
                year: "2020",
                title: "100+ पौधे लगाए",
                desc: "पूरे नगरीय क्षेत्र में वृक्षारोपण अभियान चलाया गया।",
              },
              {
                year: "2023",
                title: "ग्रीन स्कूल इनिशिएटिव",
                desc: "स्कूलों में बच्चों को पर्यावरण शिक्षा दी गई।",
              },
              {
                year: "2025",
                title: "डिजिटल ट्रैकिंग सिस्टम",
                desc: "अब हम हर पेड़ की ग्रोथ ऑनलाइन ट्रैक कर सकते हैं।",
              },
            ].map((event, i) => (
              <div key={i} className="mb-10 ml-6 relative">
                <div className="absolute w-4 h-4 bg-green-600 rounded-full -left-2.5 mt-1.5"></div>
                <h3 className="text-xl font-bold text-green-700">
                  {event.year} - {event.title}
                </h3>
                <p className="text-gray-700 ml-2">{event.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Join Section */}
      <section className="bg-green-700 text-white text-center py-16">
        <h2 className="text-3xl font-bold mb-4">
          आइए, हमारे साथ मिलकर धरती को बचाएं 🌍
        </h2>
        <p className="max-w-2xl mx-auto mb-6 text-green-100">
          हर व्यक्ति एक पेड़ लगाए, यही हमारे पर्यावरण की सच्ची रक्षा है। अभी
          जुड़ें और बनें एक सच्चे वृक्ष मित्र!
        </p>
        <a
          href="/volunteer"
          className="bg-yellow-400 text-green-900 px-6 py-3 rounded-full font-semibold hover:bg-yellow-500 transition"
        >
          हमारे साथ जुड़ें →
        </a>
      </section>
    </div>
  );
}
