import { Link } from "react-router-dom";

export default function Home() {
  const projects = [
    {
      title: "हर घर पेड़",
      desc: "हर परिवार एक पौधा लगाए — यही हमारा पहला कदम है हरियाली की ओर।",
      img: "https://cdn.pixabay.com/photo/2017/02/07/20/28/tree-2048524_1280.png",
    },
    {
      title: "ग्रीन स्कूल अभियान",
      desc: "बच्चों को पेड़ लगाने और प्रकृति से प्रेम करना सिखाना।",
      img: "https://cdn.pixabay.com/photo/2021/04/11/19/31/tree-6169988_1280.png",
    },
    {
      title: "जल संरक्षण मिशन",
      desc: "वर्षा जल संचयन और जल संरक्षण पर कार्य।",
      img: "https://cdn.pixabay.com/photo/2013/07/12/19/24/water-154549_1280.png",
    },
  ];

  return (
    <div className="bg-green-50 text-gray-800">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto flex flex-col-reverse md:flex-row items-center justify-between px-6 py-16 md:py-24">
          {/* Left Content */}
          <div className="md:w-1/2 space-y-6 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-bold text-green-800 leading-tight">
              चलो मिलकर <span className="text-green-600">धरा को हरा भरा</span>{" "}
              बनाते हैं 🌱
            </h1>
            <p className="text-lg text-gray-700">
              वृक्ष मित्र संस्था पर्यावरण की रक्षा और वृक्षारोपण को समर्पित एक
              अभियान है। आइए मिलकर पौधे लगाएँ और आने वाली पीढ़ियों के लिए एक
              हरियाली भरा भविष्य बनाएं।
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Link
                to="/volunteer"
                className="bg-green-700 text-white px-5 py-3 rounded-full font-semibold hover:bg-green-800 transition"
              >
                🌿 हमारे साथ जुड़ें
              </Link>
              <Link
                to="/donate"
                className="bg-yellow-400 text-green-900 px-5 py-3 rounded-full font-semibold hover:bg-yellow-500 transition"
              >
                💚 दान करें
              </Link>
            </div>
          </div>

          {/* Right Image */}
          <div className="md:w-1/2 flex justify-center mb-8 md:mb-0">
            <img
              src="https://cdn.pixabay.com/photo/2016/04/20/22/05/earth-1348664_960_720.png"
              alt="Green Earth"
              className="w-72 md:w-96 animate-float"
            />
          </div>
        </div>
      </section>

      {/* About Summary Section */}
      <section className="bg-white py-16">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-green-800 mb-6">
            हमारा मिशन 🌏
          </h2>
          <p className="text-gray-700 max-w-2xl mx-auto">
            वृक्ष मित्र संस्था पर्यावरण की सुरक्षा, पौधारोपण और जलवायु संतुलन के
            लिए काम करती है। हम हर वर्ष हजारों पौधे लगाते हैं और लोगों को
            पर्यावरण के प्रति जागरूक बनाते हैं।
          </p>
          <Link
            to="/about"
            className="inline-block mt-6 bg-green-700 text-white px-6 py-3 rounded-full hover:bg-green-800 transition"
          >
            और जानें →
          </Link>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 bg-green-100">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-green-800 mb-10">
            हमारे प्रमुख प्रोजेक्ट्स 🌲
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {projects.map((p, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl shadow-md hover:shadow-lg p-6 transform hover:-translate-y-1 transition"
              >
                <img
                  src={p.img}
                  alt={p.title}
                  className="w-32 h-32 mx-auto mb-4"
                />
                <h3 className="text-xl font-semibold text-green-700 mb-2">
                  {p.title}
                </h3>
                <p className="text-gray-600">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
