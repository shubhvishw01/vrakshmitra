import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import BackToTopButton from "./BackToTopButton";
import ScrollProgressBar from "./ScrollProgressBar";

const Layout = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen bg-green-50 text-gray-800">
      <ScrollProgressBar />
      <Navbar />
      <main className="p-4 md:p-8 grow bg-green-50">{children}</main>
      <Footer />
      <BackToTopButton />
    </div>
  );
};

export default Layout;
